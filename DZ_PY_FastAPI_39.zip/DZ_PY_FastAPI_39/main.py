from passlib.context import CryptContext
from datetime import datetime, timedelta
from jose import jwt, JWTError
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session

from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm


# Настройка базы данных
DATABASE_URL = "sqlite:///test.db"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# Модель пользователя
class User(Base):
    __tablename__ = "users"

    username = Column(String, primary_key=True, index=True)
    hashed_password = Column(String)
    role = Column(String)


# Создание таблиц
Base.metadata.create_all(bind=engine)

# Настройка хеширования паролей и конфигурация JWT
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = "secrettopacademy"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30


# Функции для работы с токенами
def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    expire = datetime.now() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def get_current_user(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return username
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")


def get_password_hash(password: str):
    return pwd_context.hash(password)


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


# Модели данных
class UserLogin(BaseModel):
    username: str
    password: str


class UserInDB(BaseModel):
    username: str
    hashed_password: str
    role: str


class UserCreate(BaseModel):
    username: str
    password: str
    role: str


app = FastAPI()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


# Зависимость для получения сессии базы данных
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Функция для получения текущего администратора
def get_current_admin(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    username = get_current_user(token)
    user = db.query(User).filter(User.username == username).first()
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Access forbidden")
    return username


# Функция для аутентификации пользователя
def authenticate_user(username: str, password: str, db: Session):
    user = db.query(User).filter(User.username == username).first()
    if user and verify_password(password, user.hashed_password):
        return user
    return None


# Эндпоинт для получения токена
@app.post("/token")
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = authenticate_user(form_data.username, form_data.password, db)
    if not user:
        raise HTTPException(status_code=401, detail="Incorrect user password")
    access_token = create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}


# Эндпоинт для получения информации о текущем пользователе
@app.get("/users/me")
async def read_users_me(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    username = get_current_user(token)
    return {"username": username}


# Эндпоинт для получения списка пользователей
@app.get("/users")
async def read_users(db: Session = Depends(get_db)):
    users = db.query(User).all()
    return [{"username": user.username, "role": user.role} for user in users]


# Эндпоинт для создания нового пользователя
@app.post("/users", response_model=UserInDB)
async def create_user(user: UserCreate, db: Session = Depends(get_db), admin: str = Depends(get_current_admin)):
    # Проверка на существование пользователя
    existing_user = db.query(User).filter(User.username == user.username).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Username already registered")

    # Создание нового пользователя
    new_user = User(
        username=user.username,
        hashed_password=get_password_hash(user.password),
        role=user.role
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user


# Эндпоинт для обновления информации о пользователе
@app.put("/users/{username}", response_model=UserInDB)
async def update_user(username: str, user: UserCreate, db: Session = Depends(get_db),
                      token: str = Depends(oauth2_scheme)):
    current_username = get_current_user(token)
    current_user = db.query(User).filter(User.username == current_username).first()
    target_user = db.query(User).filter(User.username == username).first()

    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    # Проверка, является ли текущий пользователь администратором или обновляет свою информацию
    if current_user.role != "admin" and current_user.username != username:
        raise HTTPException(status_code=403, detail="Access forbidden")

    # Обновление информации о пользователе
    target_user.hashed_password = get_password_hash(user.password)
    target_user.role = user.role
    db.commit()
    db.refresh(target_user)
    return target_user


# Эндпоинт для удаления пользователя
@app.delete("/users/{username}", response_model=dict)
async def delete_user(username: str, db: Session = Depends(get_db), admin: str = Depends(get_current_admin)):
    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    db.delete(user)
    db.commit()
    return {"detail": "User deleted successfully"}


# Эндпоинт для получения данных администратора
@app.get("/admin")
async def read_admin_data(admin: str = Depends(get_current_admin)):
    return {"admin_data": f"VERY SECRET for {admin}"}
