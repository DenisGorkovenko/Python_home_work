from app.utils.convert import encode_image, decode_image
from app.repositories.sqlite_orm import SQLiteRepo
from app.utils.errors import Error
from fastapi import status
from io import StringIO
import csv
import app.schemas.ingredients as sching
import app.schemas.recipes as schrec
import app.schemas.users as schuser
import app.schemas.tags as schtag
import app.db.models as models

repo = SQLiteRepo()


def get_recipe_response(recipe, user=None):
    return schrec.RecipeResponse(
        id=recipe.id,
        tags=[
            schtag.Tag(
                id=tag.id,
                name=tag.name,
                color='#E26C2D',
                slug=tag.slug
            ) for tag in recipe.tags
        ],
        author=schuser.Author(
            id=recipe.author.id,
            email=recipe.author.email,
            username=recipe.author.username,
            first_name=recipe.author.first_name,
            last_name=recipe.author.last_name,
            is_subscribed=any(subscription.id == recipe.author.id for subscription in user.subscriptions) if user else False,
            avatar=encode_image(recipe.author.avatar)
        ),
        ingredients=[
            sching.Ingredient(
                id=ingredient.id,
                name=ingredient.ingredient.name,
                measurement_unit=ingredient.ingredient.measurement_unit,
                amount=ingredient.amount
            ) for ingredient in recipe.ingredients
        ],
        is_favorited=any(favourite.id == recipe.id for favourite in user.favourites) if user else False,
        is_in_shopping_cart=False,
        name=recipe.name,
        image=encode_image(recipe.image),
        text=recipe.text,
        cooking_time=recipe.cooking_time
    )


def get_download_shopping_cart(user_id: int):
    items = repo.get_shopping_cart(user_id)
    if file_format == "csv":
        output = StringIO()
        writer = csv.writer(output)
        writer.writerow(["Название", "Количество", "Единица измерения"])

        for item in items:
            writer.writerow([item.name, item.amount, item.measurement_unit])

        response = Response(content=output.getvalue(), media_type="text/csv")
        response.headers["Content-Disposition"] = "attachment; filename=shopping_cart.csv"
        return response

    elif file_format == "pdf":
        buffer = BytesIO()
        p = canvas.Canvas(buffer, pagesize=letter)
        p.drawString(100, 750, "Корзина покупок")
        p.drawString(100, 730, "Название")
        p.drawString(300, 730, "Количество")
        p.drawString(400, 730, "Единица измерения")

        y = 710
        for item in items:
            p.drawString(100, y, item.name)
            p.drawString(300, y, str(item.amount))
            p.drawString(400, y, item.measurement_unit)
            y -= 20

        p.showPage()
        p.save()
        buffer.seek(0)

        response = Response(content=buffer.getvalue(), media_type="application/pdf")
        response.headers["Content-Disposition"] = "attachment; filename=shopping_cart.pdf"
        return response

    elif file_format == "txt":
        output = StringIO()
        output.write("Название\tКоличество\tЕдиница измерения\n")

        for item in items:
            output.write(f"{item.name}\t{item.amount}\t{item.measurement_unit}\n")

        response = Response(content=output.getvalue(), media_type="text/plain")
        response.headers["Content-Disposition"] = "attachment; filename=shopping_cart.txt"
        return response


def get_recipes(page: int,
                limit: int,
                is_favorited: int,
                is_in_shopping_cart: int,
                author: models.User,
                tags: list[str],
                url: str,
                user: models.User):
    author_id = -1
    if author:
        author_id = author.id
    tags_list = []
    if tags:
        tags_list = tags
    total, recipes = repo.get_recipes(page, limit, is_favorited, is_in_shopping_cart, author_id, tags_list, user.id)
    results = []
    for recipe in recipes:
        results.append(get_recipe_response(recipe, user))

    base_url = str(url).split("?")[0]
    next_url = (
        f"{base_url}?page={page + 1}&limit={limit}"
        if (page * limit) < total else None
    )
    previous_url = (
        f"{base_url}?page={page - 1}&limit={limit}"
        if page > 1 else None
    )
    return schrec.RecipePaginationResponse(
        count=total,
        next=next_url,
        previous=previous_url,
        results=results
    )


def get_recipe(recipe_id: int, user: models.User):
    recipe = repo.get_recipe(recipe_id)
    if not recipe:
        raise Error(status.HTTP_404_NOT_FOUND, "No recipe with this id")
    return get_recipe_response(recipe, user)


def create_recipe(recipe_data: schrec.RecipeCreate, user_id: int):
    image = decode_image(recipe_data.image)
    recipe = models.Recipe(
        name=recipe_data.name,
        image=image,
        cooking_time=recipe_data.cooking_time,
        text=recipe_data.text,
        author_id=user_id
    )
    recipe = repo.save_recipe(recipe)

    ingredients = []
    for ingredient in recipe_data.ingredients:
        db_ingredient = models.RecipeIngredient(
            recipe_id=recipe.id,
            ingredient_id=ingredient.id,
            amount=ingredient.amount
        )
        ingredients.append(db_ingredient)
    repo.save_ingredients_recipe(recipe.id, ingredients)

    ok = repo.save_tags_by_id_recipe(recipe, recipe_data.tags)
    if not ok:
        raise Error(status.HTTP_404_NOT_FOUND, "Tag not found")

    return get_recipe_response(recipe)


def update_recipe(id: int, recipe_update: schrec.RecipeUpdate, user: models.User):
    recipe = repo.get_recipe(id)
    if not recipe:
        raise Error(status.HTTP_404_NOT_FOUND, "Recipe not found")
    if recipe.author_id != user.id:
        raise Error(status.HTTP_403_FORBIDDEN, "Permission denied")

    recipe.name = recipe.name
    recipe.text = recipe.text
    recipe.cooking_time = recipe.cooking_time
    recipe.image = decode_image(recipe.image) if recipe.image != "" else None

    ingredients = []
    for ingredient in recipe.ingredients:
        db_ingredient = models.RecipeIngredient(
            recipe_id=recipe.id,
            ingredient_id=ingredient.id,
            amount=ingredient.amount
        )
        ingredients.append(db_ingredient)
    repo.save_ingredients_recipe(recipe.id, ingredients)
    ok = repo.save_tags_by_id_recipe(recipe, recipe_update.tags)
    if not ok:
        raise Error(status.HTTP_404_NOT_FOUND, "Tag not found")

    recipe = repo.update_recipe(recipe)
    return get_recipe_response(recipe, user)


def add_favourite_recipe(recipe_id: int, user: models.User):
    recipe = repo.get_recipe(recipe_id)
    if not recipe:
        raise Error(status.HTTP_404_NOT_FOUND, "Recipe not found")
    repo.add_favourite_recipe(recipe, user)


def delete_favourite_recipe(recipe_id: int, user: models.User):
    repo.delete_favourite_recipe(user.id, recipe_id)


def add_to_shopping_cart(recipe_id: int, user: models.User):
    recipe = repo.get_recipe(recipe_id)
    if not recipe:
        raise Error(status.HTTP_404_NOT_FOUND, "Recipe not found")
    exists = repo.is_recipe_in_shopping_cart(recipe_id, user.id)
    if exists:
        raise Error(status.HTTP_400_BAD_REQUEST, f"Already have recipe with ID={recipe_id} in shopping cart")
    repo.add_recipe_to_shopping_cart(recipe_id, user.id)
    return schrec.RecipeShortDataResponse(
            id=recipe.id,
            name=recipe.name,
            image=encode_image(recipe.image),
            cooking_time=recipe.cooking_time
        )


def remove_from_shopping_cart(recipe_id: int, user: models.User):
    exists = repo.is_recipe_in_shopping_cart(recipe_id, user.id)
    if exists:
        raise Error(status.HTTP_400_BAD_REQUEST, f"Haven't recipe with ID={recipe_id} in shopping cart")
    repo.delete_recipe_from_shopping_cart(recipe_id, user.id)
