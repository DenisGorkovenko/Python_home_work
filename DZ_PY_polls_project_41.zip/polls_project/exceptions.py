from fastapi import HTTPException, status


class PollNotFoundError(HTTPException):
    """Исключение для ситуаций, когда опрос не найден"""
    def __init__(self, poll_id: int):
        self.poll_id = poll_id
        detail = f"Poll with ID {poll_id} not found"
        super().__init__(status_code=404, detail=detail)


class ChoiceNotFoundError(HTTPException):
    """Исключение для ситуаций, когда вариант ответа не найден"""
    def __init__(self, choice_id: int):
        self.choice_id = choice_id
        detail = f"Choice with ID {choice_id} not found"
        super().__init__(status_code=404, detail=detail)


class FailedAuthorizationError(HTTPException):
    """Исключения для неверной авторизации"""
    def __init__(self):
        detail = f"Authorization failed"
        super().__init__(status_code=status.HTTP_401_UNAUTHORIZED, detail=detail)


class InvalidTokenError(HTTPException):
    """Исключение для неверного токена"""
    def __init__(self):
        detail = f"Invalid token"
        super().__init__(status_code=401, detail=detail)


class UserAlreadyExistError(HTTPException):
    """Исключение для регистрации существующего пользователя"""
    def __init__(self, username):
        detail = f"User with {username} username already exists"
        super().__init__(status_code=400, detail=detail)
