from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from app.api import auth, ingredients, recipes, tags, users

API = FastAPI(title="Foodgram API")


@API.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal Server Error"},
    )

API.include_router(auth.router, prefix="/api/auth")
API.include_router(ingredients.router, prefix="/api/ingredients")
API.include_router(recipes.router, prefix="/api/recipes")
API.include_router(tags.router, prefix="/api/tags")
API.include_router(users.router, prefix="/api/users")
