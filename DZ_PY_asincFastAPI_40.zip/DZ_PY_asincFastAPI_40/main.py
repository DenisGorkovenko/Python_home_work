from fastapi import FastAPI, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from pydantic import BaseModel
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base
from databases import Database
import httpx
import asyncio

DATABASE_URL = "sqlite+aiosqlite:///./quotes.db"

database = Database(DATABASE_URL)
Base = declarative_base()


# Модель Quote
class QuoteModel(Base):
    __tablename__ = "quotes"

    id = Column(Integer, primary_key=True, index=True)
    text = Column(String, index=True)
    author = Column(String, index=True)


# Создание таблицы
engine = create_async_engine(DATABASE_URL, echo=True)
async_session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def init_models() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)


# Pydantic модель для валидации данных
class Quote(BaseModel):
    text: str
    author: str


app = FastAPI()


@app.on_event('startup')
async def init_db() -> None:
    await init_models()


@app.get("/fetch-and-save-quote/", response_model=Quote)
async def fetch_and_save_quote():
    async with httpx.AsyncClient(verify=False) as client:
        response = await client.get("https://api.quotable.io/random")
        if response.status_code != 200:
            raise HTTPException(status_code=response.status_code, detail="Error fetching quote")

        data = response.json()
        quote = Quote(text=data["content"], author=data["author"])

        # Сохранение цитаты в базе данных
        query = "INSERT INTO quotes (text, author) VALUES (:text, :author)"
        values = {"text": quote.text, "author": quote.author}
        await database.execute(query=query, values=values)

        return quote


@app.get("/quotes/", response_model=list[Quote])
async def get_quotes():
    query = "SELECT * FROM quotes"
    rows = await database.fetch_all(query)
    return [Quote(text=row["text"], author=row["author"]) for row in rows]


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
