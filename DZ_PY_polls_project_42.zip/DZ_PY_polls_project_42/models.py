from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    hashed_password = Column(String, nullable=False)

    votes = relationship("Vote", back_populates="user")
    polls = relationship("Poll", back_populates="user")


class Poll(Base):
    __tablename__ = "polls"

    id = Column(Integer, primary_key=True, index=True)
    question = Column(String, index=True)
    username = Column(Integer, ForeignKey("users.username"), nullable=False)

    choices = relationship("Choice", back_populates="poll", cascade="all, delete")
    votes = relationship("Vote", back_populates="poll", cascade="all, delete")
    user = relationship("User", back_populates="polls")


class Choice(Base):
    __tablename__ = "choices"

    id = Column(Integer, primary_key=True, index=True)
    text = Column(String, index=True)
    votes = Column(Integer, default=0)
    poll_id = Column(Integer, ForeignKey("polls.id"))

    poll = relationship("Poll", back_populates="choices")


class Vote(Base):
    __tablename__ = "votes"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(Integer, ForeignKey("users.username"), nullable=False)
    poll_id = Column(Integer, ForeignKey("polls.id"))

    user = relationship("User", back_populates="votes")
    poll = relationship("Poll", back_populates="votes")
