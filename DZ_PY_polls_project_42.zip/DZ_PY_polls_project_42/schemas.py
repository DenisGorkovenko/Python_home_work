from pydantic import BaseModel
from typing import List


class ChoiceBase(BaseModel):
    text: str


class ChoiceCreate(ChoiceBase):
    pass


class ChoiceResponse(ChoiceBase):
    id: int
    votes: int

    class Config:
        from_attributes = True


class ChoiceDetailResponse(ChoiceResponse):
    percentage: float


class PollBase(BaseModel):
    question: str


class PollCreate(PollBase):
    choices: List[ChoiceCreate]


class PollResponse(PollBase):
    id: int
    choices: List[ChoiceResponse]

    class Config:
        from_attributes = True


class PollResultsResponse(PollResponse):
    total_votes: int
    choices: List[ChoiceDetailResponse]


class UserCreate(BaseModel):
    username: str
    password: str
