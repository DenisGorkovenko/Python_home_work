import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import PollsList from './components/PollsList';
import PollDetail from './components/PollDetail';
import CreatePoll from './components/CreatePoll';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/login" component={<Login />} />
        <Route path="/polls" element={<PollsList />} />
        <Route path="/polls/:id" element={<PollDetail />} />
        <Route path="/create-poll" element={<CreatePoll />} />
      </Routes>
    </Router>
  );
}

export default App;
