import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function PollsList() {
  const [polls, setPolls] = useState([]);

  useEffect(() => {
    const fetchPolls = async () => {
      try {
        const response = await axios.get('http://localhost:8000/polls/');
        setPolls(response.data);
      } catch (error) {
        console.error('Error fetching polls:', error);
      }
    };

    fetchPolls();
  }, []);

  const handleDeletePoll = async (pollId) => {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('No token found');
      return;
    }

    try {
      await axios.delete(`http://localhost:8000/polls/${pollId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setPolls(polls.filter(poll => poll.id !== pollId));
      alert('Poll deleted successfully');
    } catch (error) {
      console.error('Error deleting poll:', error);
    }
  };

  return (
    <div>
      <h2>Polls</h2>
      <ul>
        {polls.map((poll) => (
          <li key={poll.id}>
            <Link to={`/polls/${poll.id}/`}>{poll.question}</Link>
            <button onClick={() => handleDeletePoll(poll.id)}>Удалить опрос</button>
          </li>
        ))}
      </ul>
      <Link to="/create-poll">Create New Poll</Link>
    </div>
  );
}

export default PollsList;