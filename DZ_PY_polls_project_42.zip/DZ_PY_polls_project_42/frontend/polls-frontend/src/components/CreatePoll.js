import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function CreatePoll() {
  const [question, setQuestion] = useState('');
  const [choices, setChoices] = useState(['']);
  const navigate = useNavigate();

  const addChoice = () => setChoices([...choices, '']);

  const handleChoiceChange = (index, value) => {
    const updatedChoices = choices.map((choice, i) => (i === index ? value : choice));
    setChoices(updatedChoices);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(
        'http://localhost:8000/polls/',
        {
          question,
          choices: choices.map((text) => ({ text }))
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
          }
        }
      );
      navigate('/polls');
    } catch (error) {
      console.error('Error creating poll:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create Poll</h2>
      <input type="text" placeholder="Question" value={question} onChange={(e) => setQuestion(e.target.value)} required />
      {choices.map((choice, index) => (
        <input
          key={index}
          type="text"
          placeholder={`Choice ${index + 1}`}
          value={choice}
          onChange={(e) => handleChoiceChange(index, e.target.value)}
          required
        />
      ))}
      <button type="button" onClick={addChoice}>Add Choice</button>
      <button type="submit">Create Poll</button>
    </form>
  );
}

export default CreatePoll;
