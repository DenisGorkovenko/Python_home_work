import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function PollDetail({ token }) {
  const { id } = useParams();
  const [poll, setPoll] = useState(null);
  const [selectedChoice, setSelectedChoice] = useState(null);

  useEffect(() => {
    const fetchPollDetail = async () => {
      try {
        const response = await axios.get(`http://localhost:8000/polls/${id}/details/`);
        setPoll(response.data);
      } catch (error) {
        console.error('Error fetching poll details:', error);
      }
    };

    fetchPollDetail();
  }, [id]);

  const handleVote = async (choiceId) => {
    try {
      await axios.post(`http://localhost:8000/choices/${choiceId}/vote`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      });
      setSelectedChoice(choiceId);
      const response = await axios.get(`http://localhost:8000/polls/${id}/details/`);
      setPoll(response.data);
    } catch (error) {
      console.error('Error voting:', error);
    }
  };

  if (!poll) return <p>Loading...</p>;

  return (
    <div>
      <h2>{poll.question}</h2>
      <ul>
        {poll.choices.map((choice) => (
          <li key={choice.id}>
            {choice.text} - {choice.votes} votes ({choice.percentage}%)
            <button onClick={() => handleVote(choice.id)} disabled={selectedChoice !== null}>
              Голосовать
            </button>
          </li>
        ))}
      </ul>
      {selectedChoice && <p>Thank you for voting!</p>}
    </div>
  );
}

export default PollDetail;