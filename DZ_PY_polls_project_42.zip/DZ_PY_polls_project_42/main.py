from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from datetime import datetime
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware

from database import SessionLocal, engine
from exceptions import *
from auth import *
import models
import crud
import schemas
import uvicorn


models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Polls API")

origins = [
    "http://localhost:3000",
    "http://127.0.0.1:3000"
]

# Добавляем CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == form_data.username).first()
    if not user or not verify_token(form_data.password, user.hashed_password):
        raise FailedAuthorizationError()
    access_token = create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}


@app.post("/register")
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_username(db, username=user.username)
    if db_user:
        raise UserAlreadyExistError(user.username)

    new_user = crud.create_user(db, username=user.username, hashed_password=get_password_hash(user.password))
    return {"message": "user created successfully", "username": new_user.username}


@app.get("/users/me")
def read_users_me(token: str = Depends(oauth2_scheme)):
    payload = decode_token(token)
    if not payload:
        raise InvalidTokenError()
    return {"username": payload.get("sub")}


@app.get("/polls/", response_model=list[schemas.PollResponse])
def read_polls(db: Session = Depends(get_db), keyword: str | None = None):
    polls = crud.get_polls(db)
    if keyword:
        polls = [poll for poll in polls if keyword.lower() in poll.question.lower()]
    return polls


@app.get("/polls/{poll_id}/details", response_model=schemas.PollResultsResponse)
def read_detail_polls(poll_id: int, db: Session = Depends(get_db)):
    db_poll = crud.get_poll_results(db, poll_id)
    if not db_poll:
        raise PollNotFoundError(poll_id=poll_id)
    return db_poll


@app.post("/polls/", response_model=schemas.PollResponse)
def create_poll(poll: schemas.PollCreate, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    payload = decode_token(token)
    if not payload:
        raise InvalidTokenError()
    username = payload.get("sub")
    return crud.create_poll(db, poll, username)


@app.get("/polls/{poll_id}/", response_model=schemas.PollResponse)
def read_poll(poll_id: int, db: Session = Depends(get_db)):
    db_poll = crud.get_poll(db, poll_id)
    if not db_poll:
        raise PollNotFoundError(poll_id=poll_id)
    return db_poll


@app.post("/choices/{choice_id}/vote", response_model=schemas.ChoiceResponse)
def vote(choice_id: int, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    payload = decode_token(token)
    if not payload:
        raise InvalidTokenError()

    username = payload.get("sub")
    db_choice = crud.vote_for_choice(db, choice_id, username)
    return db_choice


@app.delete("/polls/{poll_id}", response_model=schemas.PollResponse)
def delete_poll(poll_id: int, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    payload = decode_token(token)
    if not payload:
        raise InvalidTokenError()

    username = payload.get("sub")
    db_poll = crud.delete_poll(db, poll_id, username)
    return db_poll


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)

