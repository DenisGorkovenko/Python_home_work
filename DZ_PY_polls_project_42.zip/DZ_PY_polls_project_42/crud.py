from sqlalchemy.orm import Session
from models import Poll, Choice, Vote, User
from schemas import PollCreate

from exceptions import *


def get_polls(db: Session):
    return db.query(Poll).all()


def get_poll(db: Session, poll_id: int):
    return db.query(Poll).filter(Poll.id == poll_id).first()


def create_poll(db: Session, poll: PollCreate, username: str):
    db_poll = Poll(question=poll.question, username=username)
    for choice in poll.choices:
        db_poll.choices.append(Choice(text=choice.text))
    db.add(db_poll)
    db.commit()
    db.refresh(db_poll)
    return db_poll


def vote_for_choice(db: Session, choice_id: int, username: str):
    db_choice = db.query(Choice).filter(Choice.id == choice_id).first()
    if not db_choice:
        raise ChoiceNotFoundError(choice_id=choice_id)

    poll_id = db_choice.poll_id
    existing_vote = db.query(Vote).filter((Vote.username == username) & (Vote.poll_id == poll_id)).first()
    if existing_vote:
        raise UserAlreadyVotedError(username=username, poll_id=poll_id)

    db_choice.votes += 1
    db.add(Vote(username=username, poll_id=poll_id))
    db.commit()
    db.refresh(db_choice)
    return db_choice


def delete_poll(db: Session, poll_id: int, username: str):
    db_poll = get_poll(db, poll_id)
    if not db_poll:
        raise PollNotFoundError(poll_id=poll_id)

    if db_poll.username != username:
        raise FailedDeleteError(username=username)

    db.delete(db_poll)
    db.commit()
    return db_poll


def get_poll_results(db: Session, poll_id: int):
    poll = get_poll(db, poll_id)
    if not poll:
        return None

    total_votes = sum(choice.votes for choice in poll.choices)

    choices = [{"id": choice.id,
                "text": choice.text,
                "votes": choice.votes,
                "percentage": round((choice.votes / total_votes) * 100, 2) if total_votes > 0 else 0
                } for choice in poll.choices]

    return {
        "id": poll.id,
        "question": poll.question,
        "total_votes": total_votes,
        "choices": choices
    }


def get_user_by_username(db: Session, username: str):
    return db.query(User).filter(User.username == username).first()


def create_user(db: Session, username: str, hashed_password: str):
    db_user = User(username=username, hashed_password=hashed_password)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


