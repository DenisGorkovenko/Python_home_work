from pydantic import BaseModel
from datetime import datetime


class NoteBase(BaseModel):
    title: str
    content: str | None = None


class NoteCreate(NoteBase):
    pass


class NoteUpdate(NoteBase):
    pass


class Note(NoteBase):
    id: int
    current_date: datetime

    class Config:
        from_attributes = True


class History(BaseModel):
    id: int
    note_id: int
    new_value: str
    change_time: datetime

    class Config:
        from_attributes = True
