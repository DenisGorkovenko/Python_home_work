from fastapi import HTTPException


class NoteNotFoundError(HTTPException):
    """Исключение для ситуаций, когда заметка не найдена"""
    def __init__(self, note_id: int):
        self.note_id = note_id
        detail = f"Note with ID {note_id} not found"
        super().__init__(status_code=404, detail=detail)
