from sqlalchemy import Column, Integer, String, DateTime, func, ForeignKey
from sqlalchemy.orm import relationship
from database import Base


class Note(Base):
    __tablename__ = "notes"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True, nullable=False)
    content = Column(String, nullable=True)
    current_date = Column(DateTime(timezone=True), onupdate=func.now(), default=func.now())

    history = relationship("ChangeHistory", back_populates="note")


class ChangeHistory(Base):
    __tablename__ = 'change_history'

    id = Column(Integer, primary_key=True, index=True)
    note_id = Column(Integer, ForeignKey('notes.id'))
    new_value = Column(String)
    change_time = Column(DateTime(timezone=True), onupdate=func.now(), default=func.now())

    note = relationship("Note", back_populates="history")