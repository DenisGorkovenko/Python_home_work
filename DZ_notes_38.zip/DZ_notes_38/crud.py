from sqlalchemy.orm import Session
import models
import schemas


def get_notes(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.Note).order_by(models.Note.current_date.desc()).offset(skip).limit(limit).all()


def get_note(db: Session, note_id: int):
    return db.query(models.Note).filter(models.Note.id == note_id).first()


def create_note(db: Session, note: schemas.NoteCreate):
    new_note = models.Note(**note.dict())
    db.add(new_note)
    db.commit()
    db.refresh(new_note)

    history_entry = models.ChangeHistory(note_id=new_note.id, new_value=f"Создана запись: {note.title} - {note.content}")
    db.add(history_entry)
    db.commit()
    return new_note


def update_note(db: Session, note_id: int, note: schemas.NoteUpdate):
    upd_note = get_note(db=db, note_id=note_id)
    if not upd_note:
        return None

    for key, value in note.dict().items():
        setattr(upd_note, key, value)
    db.commit()
    db.refresh(upd_note)

    history_entry = models.ChangeHistory(note_id=upd_note.id, new_value=f"Внесены изменения: {note.title} - {note.content}")
    db.add(history_entry)
    db.commit()
    return upd_note


def delete_note(db: Session, note_id: int):
    note = get_note(db=db, note_id=note_id)

    if note:
        db.delete(note)
        db.commit()

    history_entry = models.ChangeHistory(note_id=note.id,
                                         new_value=f"Удалена запись № {note.id}")
    db.add(history_entry)
    db.commit()
    return note


def get_change_history(db: Session, note_id: int, days: int):
    from datetime import datetime, timedelta
    time_threshold = datetime.utcnow() - timedelta(days=days)
    return db.query(models.ChangeHistory).filter(models.ChangeHistory.note_id == note_id,
                                                 models.ChangeHistory.change_time >= time_threshold).all()
