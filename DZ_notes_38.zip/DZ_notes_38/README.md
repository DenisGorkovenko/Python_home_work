Установка зависимостей:
```pip install -r requirements.txt```

Запуск сервера:
```uvicorn main:app```