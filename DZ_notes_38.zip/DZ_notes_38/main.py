from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from typing import List
from database import get_db, engine, Base
from exceptions import NoteNotFoundError
import crud
import schemas

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Note API")


@app.get("/notes/", response_model=list[schemas.Note])
def read_notes(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_notes(db=db, skip=skip, limit=limit)


@app.get("/notes/{note_id}", response_model=schemas.Note)
def read_note(note_id: int, db: Session = Depends(get_db)):
    note = crud.get_note(db=db, note_id=note_id)
    if not note:
        raise NoteNotFoundError(note_id=note_id)
    return note


@app.post("/notes/", response_model=schemas.Note)
def create_note(note: schemas.NoteCreate, db: Session = Depends(get_db)):
    return crud.create_note(db=db, note=note)


@app.put("/notes/{note_id}", response_model=schemas.Note)
def update_note(note_id: int, note: schemas.NoteUpdate, db: Session = Depends(get_db)):
    updated_note = crud.update_note(db=db, note_id=note_id, note=note)
    if not updated_note:
        raise NoteNotFoundError(note_id=note_id)
    return updated_note


@app.delete("/notes/{note_id}", response_model=schemas.Note)
def delete_note(note_id: int, db: Session = Depends(get_db)):
    deleted_note = crud.delete_note(db=db, note_id=note_id)
    if not deleted_note:
        raise NoteNotFoundError(note_id=note_id)
    return deleted_note


@app.get("/notes/{note_id}/history", response_model=List[schemas.History])
def get_change_history(note_id: int, days: int = 7, db: Session = Depends(get_db)):
    history = crud.get_change_history(db=db, note_id=note_id, days=days)

    if not history:
        raise NoteNotFoundError(note_id=note_id)

    return history
